package com.android.a14n12.tinhdiemthpt.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.android.a14n12.tinhdiemthpt.R;

public class NhapDiemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhap_diem);
    }
}
